-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2023 at 11:11 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abc`
--

-- --------------------------------------------------------

--
-- Table structure for table `assesments`
--

CREATE TABLE `assesments` (
  `id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `section_name` varchar(255) DEFAULT NULL,
  `question` text DEFAULT NULL,
  `question_image` varchar(255) DEFAULT NULL,
  `question_code` text DEFAULT NULL,
  `option1` varchar(255) DEFAULT NULL,
  `option2` varchar(255) DEFAULT NULL,
  `option3` varchar(255) DEFAULT NULL,
  `option4` varchar(255) DEFAULT NULL,
  `option1_img` varchar(255) DEFAULT NULL,
  `option2_img` varchar(255) DEFAULT NULL,
  `option3_img` varchar(255) DEFAULT NULL,
  `option4_img` varchar(255) DEFAULT NULL,
  `answer` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assesment_results`
--

CREATE TABLE `assesment_results` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_answer` varchar(255) DEFAULT NULL,
  `score` varchar(255) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `section_name` varchar(255) DEFAULT NULL,
  `questions` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE `auth` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `auth`
--

INSERT INTO `auth` (`id`, `name`, `email`, `phone`, `password`, `type`, `created_at`, `updated_at`) VALUES
(1, 'student', 'student@abc.com', '9876543210', '$2y$10$8Bn3wWop12CknREppJwwFe0ZzFlkndjs9KHxvw5z2v8usXVRu90gu', 'student', '2023-04-19 08:21:47', '2023-04-19 08:21:47'),
(2, 'admin', 'admin@abc.com', '8765432894', '$2y$10$8Bn3wWop12CknREppJwwFe0ZzFlkndjs9KHxvw5z2v8usXVRu90gu', 'admin', '2023-04-19 08:23:41', '2023-04-19 08:23:41'),
(3, 'trainer', 'trainer@abc.com', '9876545678', '$2y$10$8Bn3wWop12CknREppJwwFe0ZzFlkndjs9KHxvw5z2v8usXVRu90gu', 'trainer', '2023-04-19 08:24:28', '2023-04-19 08:24:28'),
(4, 'Recruiter', 'recruiter@abc.com', '6789987655', '$2y$10$tQkwX1UvRk78IutqR7N9xODExK8xXAG1VSxxxEeZuCNd1qQUoqCeS', 'recruiter', '2023-04-19 08:28:48', '2023-04-19 08:28:48');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `course_subject` varchar(255) DEFAULT NULL,
  `course_type` varchar(255) DEFAULT NULL,
  `course_category` varchar(255) DEFAULT NULL,
  `course_subcategory` varchar(255) DEFAULT NULL,
  `course_tutor` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `course_image` varchar(255) DEFAULT NULL,
  `course_video` varchar(255) DEFAULT NULL,
  `course_cost` varchar(255) DEFAULT NULL,
  `course_benifits` varchar(255) DEFAULT NULL,
  `course_requirements` varchar(255) DEFAULT NULL,
  `course_tags` varchar(255) DEFAULT NULL,
  `sections` longtext DEFAULT NULL,
  `section_name` text DEFAULT NULL,
  `section_desc` text DEFAULT NULL,
  `section_video` text DEFAULT NULL,
  `section_file` text DEFAULT NULL,
  `section_count` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `course_name`, `course_subject`, `course_type`, `course_category`, `course_subcategory`, `course_tutor`, `description`, `course_image`, `course_video`, `course_cost`, `course_benifits`, `course_requirements`, `course_tags`, `sections`, `section_name`, `section_desc`, `section_video`, `section_file`, `section_count`) VALUES
(1, 'Java Basics to advanced', '1', 'Development', 'developement', 'developement', '3', 'Learn java from basics to advanced', 'uploads\\AI7H1681894157.jpg', 'uploads\\efTB1681894157.mp4', '999', 'Learn java from basics to advanced', 'Learn java from basics to advanced', 'java, developement', '[{\"id\":0,\"section_name\":\"Java Basics\",\"section_desc\":\"java Basics\"},{\"id\":1,\"section_name\":\"Loops\",\"section_desc\":\"Loops\"},{\"id\":2,\"section_name\":\"Strings\",\"section_desc\":\"Strings\"},{\"id\":3,\"section_name\":\"Arrays\",\"section_desc\":\"Arrays\"}]', NULL, NULL, NULL, NULL, '4');

-- --------------------------------------------------------

--
-- Table structure for table `enrolled_courses`
--

CREATE TABLE `enrolled_courses` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `internships`
--

CREATE TABLE `internships` (
  `id` int(11) NOT NULL,
  `internship_title` varchar(255) NOT NULL,
  `internship_image` char(255) DEFAULT NULL,
  `stipend` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `criteria` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `internship_applications`
--

CREATE TABLE `internship_applications` (
  `id` int(11) NOT NULL,
  `internship_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE `job_applications` (
  `id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_details`
--

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `job_image` varchar(255) DEFAULT NULL,
  `annual_ctc` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `criteria` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `receiver_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mini_projects`
--

CREATE TABLE `mini_projects` (
  `id` int(11) NOT NULL,
  `course_id` varchar(255) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `project_image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `qnas`
--

CREATE TABLE `qnas` (
  `id` int(11) NOT NULL,
  `question` text DEFAULT NULL,
  `course` int(11) DEFAULT NULL,
  `q_created_by` int(11) DEFAULT NULL,
  `answer` text DEFAULT NULL,
  `a_created_by` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quizes`
--

CREATE TABLE `quizes` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `questions` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_masters`
--

CREATE TABLE `quiz_masters` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `question` text DEFAULT NULL,
  `question_image` varchar(255) DEFAULT NULL,
  `question_code` text DEFAULT NULL,
  `option1` varchar(255) DEFAULT NULL,
  `option2` varchar(255) DEFAULT NULL,
  `option3` varchar(255) DEFAULT NULL,
  `option4` varchar(255) DEFAULT NULL,
  `option1_img` varchar(255) DEFAULT NULL,
  `option2_img` varchar(255) DEFAULT NULL,
  `option3_img` varchar(255) DEFAULT NULL,
  `option4_img` varchar(255) DEFAULT NULL,
  `answer` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_results`
--

CREATE TABLE `quiz_results` (
  `id` int(11) NOT NULL,
  `user_id` int(255) DEFAULT NULL,
  `user_answer` varchar(255) DEFAULT NULL,
  `score` varchar(255) DEFAULT NULL,
  `quiz_id` varchar(255) DEFAULT NULL,
  `questions` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recruiters`
--

CREATE TABLE `recruiters` (
  `id` int(11) NOT NULL,
  `recruiter_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `org_address` varchar(255) DEFAULT NULL,
  `org_logo` varchar(255) DEFAULT NULL,
  `org_phone` varchar(255) DEFAULT NULL,
  `org_email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `user_id_f` int(11) DEFAULT NULL,
  `student_id` varchar(11) DEFAULT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `l_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `whatsapp_no` varchar(255) DEFAULT NULL,
  `same_as_phone` varchar(20) NOT NULL DEFAULT '0',
  `same_as_comm_address` varchar(20) NOT NULL DEFAULT '0',
  `dob` date DEFAULT NULL,
  `courses` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `reviews` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `qna` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `aadhar` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `comm_state` varchar(255) DEFAULT NULL,
  `religion` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `f_aadhar` varchar(255) DEFAULT NULL,
  `f_phone` varchar(255) DEFAULT NULL,
  `f_email_id` varchar(255) DEFAULT NULL,
  `father_aadhar_doc` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `m_aadhar` varchar(255) DEFAULT NULL,
  `m_phone` varchar(255) DEFAULT NULL,
  `m_email_id` varchar(255) DEFAULT NULL,
  `mother_aadhar_doc` varchar(255) DEFAULT NULL,
  `siblings` varchar(255) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `board` varchar(200) DEFAULT NULL,
  `annual_income` varchar(255) DEFAULT NULL,
  `physically` varchar(255) DEFAULT NULL,
  `student_image` varchar(255) DEFAULT NULL,
  `comm_address` varchar(255) DEFAULT NULL,
  `comm_village` varchar(255) DEFAULT NULL,
  `comm_block` varchar(255) DEFAULT NULL,
  `comm_pin_code` varchar(255) DEFAULT NULL,
  `perm_address` varchar(255) DEFAULT NULL,
  `perm_village` varchar(255) DEFAULT NULL,
  `perm_block` varchar(255) DEFAULT NULL,
  `perm_state` varchar(255) DEFAULT NULL,
  `perm_pin_code` varchar(255) DEFAULT NULL,
  `account_no` varchar(255) DEFAULT NULL,
  `re_account_no` varchar(255) DEFAULT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_branch` varchar(255) DEFAULT NULL,
  `name_as_per_bank` varchar(255) DEFAULT NULL,
  `admission_toggle` varchar(255) DEFAULT NULL,
  `institute_city` varchar(255) DEFAULT NULL,
  `institute_state` varchar(255) DEFAULT NULL,
  `total_fees` varchar(255) DEFAULT NULL,
  `course_span` varchar(255) DEFAULT NULL,
  `identity_proof` varchar(255) DEFAULT NULL,
  `address_proof` varchar(255) DEFAULT NULL,
  `passbook_statement` varchar(255) DEFAULT NULL,
  `academic_type` varchar(255) DEFAULT NULL COMMENT 'school-1,college-2',
  `academic_name` varchar(255) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `cgpa` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `academic_other_name` varchar(400) DEFAULT NULL,
  `hobby` varchar(255) DEFAULT NULL,
  `achievements` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `mother_tongue` varchar(255) DEFAULT NULL,
  `basic_flag` varchar(255) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `logs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `subject_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_name`, `created_at`, `updated_at`) VALUES
(1, 'Java', '2023-04-19 08:38:32', '2023-04-19 08:38:32'),
(5, 'Python', '2023-04-19 08:41:35', '2023-04-19 08:41:35');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `video_details` longtext DEFAULT NULL,
  `video_name` varchar(255) DEFAULT NULL,
  `video_file` varchar(255) DEFAULT NULL,
  `video_desc` text DEFAULT NULL,
  `video_count` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `course_id`, `section_id`, `video_details`, `video_name`, `video_file`, `video_desc`, `video_count`, `created_at`, `updated_at`) VALUES
(1, 1, 0, NULL, 'part-1,part-2', 'uploadspM9v1681894942.mp4,uploadstkmw1681894942.mp4', 'part-1,part2', 2, '2023-04-19 09:02:22', '2023-04-19 09:02:22'),
(2, 1, 1, NULL, 'loops part-1,loops part-2', 'uploadsUaAD1681894995.mp4,uploadsiuc71681894995.mp4', 'part-1,part-2', 2, '2023-04-19 09:03:15', '2023-04-19 09:03:15'),
(3, 1, 2, NULL, 'strings-1,strings-2', 'uploadsVjVo1681895042.mp4', 'strings-1,strings', 2, '2023-04-19 09:04:02', '2023-04-19 09:04:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assesments`
--
ALTER TABLE `assesments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assesment_results`
--
ALTER TABLE `assesment_results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enrolled_courses`
--
ALTER TABLE `enrolled_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `internships`
--
ALTER TABLE `internships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `internship_applications`
--
ALTER TABLE `internship_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_details`
--
ALTER TABLE `job_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mini_projects`
--
ALTER TABLE `mini_projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qnas`
--
ALTER TABLE `qnas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quizes`
--
ALTER TABLE `quizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_masters`
--
ALTER TABLE `quiz_masters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_results`
--
ALTER TABLE `quiz_results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recruiters`
--
ALTER TABLE `recruiters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assesments`
--
ALTER TABLE `assesments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assesment_results`
--
ALTER TABLE `assesment_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth`
--
ALTER TABLE `auth`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `enrolled_courses`
--
ALTER TABLE `enrolled_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `internships`
--
ALTER TABLE `internships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `internship_applications`
--
ALTER TABLE `internship_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_applications`
--
ALTER TABLE `job_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_details`
--
ALTER TABLE `job_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mini_projects`
--
ALTER TABLE `mini_projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qnas`
--
ALTER TABLE `qnas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quizes`
--
ALTER TABLE `quizes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quiz_masters`
--
ALTER TABLE `quiz_masters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quiz_results`
--
ALTER TABLE `quiz_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recruiters`
--
ALTER TABLE `recruiters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
